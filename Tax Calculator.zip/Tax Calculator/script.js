document.getElementById('taxForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var grossIncome = parseFloat(document.getElementById('gross_income').value);
    var extraIncome = parseFloat(document.getElementById('extra_income').value);
    var age = document.getElementById('age').value;
    var deductions = parseFloat(document.getElementById('deductions').value);

    var error = false;

    if (isNaN(grossIncome)) {
        document.getElementById('gross_income_error').style.display = 'inline';
        error = true;
    } else {
        document.getElementById('gross_income_error').style.display = 'none';
    }

    if (isNaN(extraIncome)) {
        document.getElementById('extra_income_error').style.display = 'inline';
        error = true;
    } else {
        document.getElementById('extra_income_error').style.display = 'none';
    }

    if (age === '') {
        document.getElementById('age_error').style.display = 'inline';
        error = true;
    } else {
        document.getElementById('age_error').style.display = 'none';
    }

    if (isNaN(deductions)) {
        document.getElementById('deductions_error').style.display = 'inline';
        error = true;
    } else {
        document.getElementById('deductions_error').style.display = 'none';
    }

    if (!error) {
        var tax = 0;
        var taxableIncome = grossIncome + extraIncome - deductions;
        if (taxableIncome > 800000) {
            switch (age) {
                case '<40':
                    tax = 0.3 * (taxableIncome - 800000);
                    break;
                case '>=40&<60':
                    tax = 0.4 * (taxableIncome - 800000);
                    break;
                case '>=60':
                    tax = 0.1 * (taxableIncome - 800000);
                    break;
                default:
                    break;
            }
        }
        var modalText = 'Your overall income will be : ' + tax.toFixed(2) + ' Lakhs';
        document.getElementById('modalText').innerText = modalText;
        document.getElementById('myModal').style.display = 'block';
    }
});

document.getElementsByClassName('close')[0].addEventListener('click', function () {
    document.getElementById('myModal').style.display = 'none';
});

window.onclick = function (event) {
    if (event.target == document.getElementById('myModal')) {
        document.getElementById('myModal').style.display = 'none';
    }
};